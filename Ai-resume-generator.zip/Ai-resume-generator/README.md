# AI Resume Generator (Flask)

AI Resume Generator is a Flask web app that lets users register/login (email + OTP + Google OAuth), fill a resume form, preview across multiple templates, and export a PDF. It also includes AI-assisted features (bullets/summary/ATS help, resume import parsing) and an Admin panel for monitoring and management.

## Table of contents

- [Tech stack](#tech-stack)
- [Key features](#key-features)
- [How the system works](#how-the-system-works)
  - [Authentication flows](#authentication-flows)
  - [Resume builder + preview + export](#resume-builder--preview--export)
  - [AI features](#ai-features)
  - [Admin panel](#admin-panel)
- [Project structure](#project-structure)
- [Database](#database)
- [Routes](#routes)
- [Configuration (.env)](#configuration-env)
- [Local setup](#local-setup)
- [Troubleshooting](#troubleshooting)
- [Security notes](#security-notes)

## Tech stack

**Backend**
- Python + Flask (`app.py`)
- SQLAlchemy ORM + Flask-SQLAlchemy (SQLite by default)
- Authlib (Google OAuth)
- SMTP (email OTPs)

**Frontend**
- Jinja2 templates (`templates/`)
- Bootstrap 5
- Vanilla JS (`static/js/app.js`)
- Custom CSS (`static/css/style.css`)
- Chart.js (Admin analytics page)

**PDF**
- WeasyPrint (`resumegenerate.py`) for HTML → PDF

**AI providers** (install/configure one)
- OpenAI (`openai`)
- Google Gemini (`google-generativeai`)
- Groq (`groq`)

## Key features

**User**
- Email registration + verification OTP
- Email login (email-first)
  - Password users: email → password
  - Google-only users (no password stored): email → OTP (`/login/verify`)
- Google OAuth login (`/google-login`)
- Forgot password: email → OTP → set new password (`/forgot-password`)
- Resume form with:
  - Technical skills tags + “Remove all”
  - Optional project description (auto-generated via AI if empty)
  - Photo upload (PNG/JPG/JPEG/WEBP, max 1 MB)
- Template preview and PDF export (Templates 1–9)
- Import an existing resume (PDF/DOCX/TXT) and auto-fill the form (AI parsing + fallback parsing)

**Admin**
- Separate admin authentication + session
- Dashboard overview stats
- Users list + view + ban/unban + delete
- Resume activity (based on last download fields)
- Feedback list + delete + filter by rating
- Analytics charts (users/resumes per day, rating distribution)
- Template usage (based on downloaded PDF filenames)
- File manager for generated PDFs
- System settings (maintenance mode + SMTP settings)
- Admin activity logs

## How the system works

### Authentication flows

The app uses **two separate sessions**:
- `session["user"]` for normal users
- `session["admin"]` for admin users

**Email signup**
1. User registers (`/register`)
2. App emails a verification code
3. User verifies (`/verify`)

**Email login (email-first)**
1. User enters email on `/login`
2. App checks the `User` record:
   - If `User.password` exists → show password stage
   - If `User.password` is empty (Google-only user) → send OTP and redirect to `/login/verify`

**Google login**
- OAuth flow via Authlib
- If it is a new Google user, the account is created with `password=None` and `is_verified=True`

**Forgot password**
1. User enters email on `/forgot-password`
2. If user exists → send OTP
3. User enters OTP
4. User sets new password (password + confirm)

**Banned users**
- User accounts can be banned via admin panel. Banned users are blocked from protected areas and forced to log out.

Mermaid overview (email-first login):

```mermaid
flowchart TD
  A[User enters email] --> B{User exists?}
  B -- No --> C[Redirect to /register]
  B -- Yes --> D{Verified?}
  D -- No --> E[Redirect to /verify]
  D -- Yes --> F{Has password?}
  F -- Yes --> G[Show password stage]
  F -- No --> H[Send OTP]
  H --> I[/login/verify]
  I --> J[Create session['user'] and redirect home]
```

### Resume builder + preview + export

The resume data has **two shapes**:
- **Form state**: the raw form fields stored per user (`User.saved_resume_data`)
- **Render data**: a normalized dict used by templates (`extract_resume_data(...)`)

Main flow:
1. User edits form at `/resume`
2. Save to DB: `/resume/save` updates `User.saved_resume_data`
3. Preview: `/preview` renders `templates/resume_preview.html`, which embeds `templates/resume_template_embed.html`
4. Export: `/export/pdf` or `/generate` generates a PDF via `WeasyPrint` and returns it as a download

Generated PDFs are written into the `resumes/` directory by `resumegenerate.py`.

Mermaid overview (resume export):

```mermaid
flowchart TD
  A[/resume form/] --> B[/preview/]
  B --> C[Choose template/customize]
  C --> D[/export/pdf/ or /generate/]
  D --> E[WeasyPrint HTML->PDF]
  E --> F[Write file to /resumes]
  F --> G[Send PDF as download]
```

### AI features

AI utilities live in `ai_utils.py` and can use **Groq / OpenAI / Gemini** depending on environment variables.

User-facing AI features include:
- Generate bullet points (`/api/ai/generate-bullets`)
- Optimize resume content (`/api/ai/optimize-content`)
- Extract skills from a JD (`/api/ai/extract-skills`)
- Generate summary (`/api/ai/generate-summary`)
- Improve a bullet/description (`/api/ai/improve-description`)
- ATS endpoints:
  - `/api/ai/ats-summary`
  - `/api/ai/ats-project` (used to auto-fill missing project descriptions)
  - `/api/ai/ats-experience`
- Apply AI to multiple sections (`/api/ai/apply-ai`)

**Resume import parsing**
- Homepage includes an “Upload old resume” option
- `/resume/import` extracts text from:
  - PDF via `pypdf`
  - DOCX via `python-docx`
  - TXT via UTF-8/Latin-1 fallback
- Then calls `ai_utils.parse_resume_form_state()` to return a JSON object that matches the app form schema
- If AI parsing fails, a basic heuristic fallback parser is used

### Frontend behaviors

Shared JS/CSS utilities:
- Flash messages auto-dismiss after ~3 seconds (`.app-alert`, via `static/js/app.js`).
- OTP inputs use a 6-box UI where applicable (`data-otp-boxes`, via `static/js/app.js` + CSS).
- Password fields use an eye toggle button instead of a “show password” checkbox (`data-password-toggle`).

### Admin panel

Admin panel routes are under `/admin/*` and require `session["admin"]`.

Important notes:
- The first admin can be created automatically using `.env` variables: `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
- Admin Settings are stored in DB (`AdminSetting`) and can be used for:
  - Maintenance mode
  - SMTP settings (used as fallback if `.env` is not set)
- Admin logs are stored in DB (`AdminLog`) for key actions (login/logout, deletions, bans, settings updates).

**Maintenance mode**
- Admin can enable it in `/admin/settings` (`maintenance_mode=1`).
- When enabled, non-admin users are blocked from resume generation + AI endpoints and redirected to home with a flash message.

## Project structure

Top-level files/folders:

```
.
├─ app.py                      # Main Flask app: models, routes, helpers
├─ ai_utils.py                  # AI provider routing + prompts + helpers
├─ resumegenerate.py            # WeasyPrint PDF generation (writes to /resumes)
├─ requirements.txt
├─ .env.example
├─ QUICK_START.md               # Short setup guide
├─ AI_SETUP.md                  # Detailed AI provider setup notes
├─ templates/
│  ├─ *.html                    # User-facing pages
│  ├─ admin/                    # Admin panel pages (layout + sections)
│  └─ resume_templates/         # Templates 1..9 for resume rendering
├─ static/
│  ├─ css/style.css             # UI + components styling (OTP boxes, required marks, etc.)
│  └─ js/app.js                 # Shared JS (flash auto-dismiss, OTP boxes, password eye toggle)
├─ resumes/                     # Generated PDFs (created at runtime)
└─ uploaded_photos/             # Uploaded profile photos (created at runtime)
```

## File-by-file guide

Top-level:
- `app.py`: Flask app entrypoint; defines DB models, helpers, user/admin routes, and API endpoints.
- `ai_utils.py`: Provider routing (Groq/OpenAI/Gemini), prompts, output cleanup, and AI parsing (`parse_resume_form_state`).
- `resumegenerate.py`: WeasyPrint wrapper that generates PDFs into `./resumes`.
- `requirements.txt`: Python dependencies (includes optional resume import + AI providers).
- `AI_SETUP.md`: Extended notes for AI provider configuration.
- `AI_TEMPLATE_EXAMPLE.html`: Example UI snippet for AI endpoints (reference only).
- `QUICK_START.md`: Quick local setup steps.

Templates:
- `templates/home.html`: Landing page + stats + (logged-in) resume import upload form.
- `templates/register.html`: Email signup.
- `templates/verify.html`: Email verification OTP (6-box UI).
- `templates/login.html`: Email-first login page (password stage uses eye toggle).
- `templates/login_verify.html`: Login OTP (6-box UI) for Google-only accounts.
- `templates/forgot_password.html`: Email → OTP → reset password flow (6-box UI).
- `templates/set_password.html`: Set password (for Google accounts who choose to add one).
- `templates/google_password_choice.html`: Post-Google sign-in screen (create password or continue Google-only).
- `templates/account.html`: Account overview.
- `templates/resume.html`: Main resume form (required-field marks, skills tags, optional project desc + AI autofill, photo upload).
- `templates/resume_preview.html`: Preview + template customization + inline edit + export.
- `templates/resume_pdf.html`: Wrapper used for PDF render.
- `templates/resume_template_embed.html`: Single-template renderer used by preview/thumbs.
- `templates/_resume_document.html`: Dispatches to template 1..9.
- `templates/_profile_links.html`: Partial for profile links UI.
- `templates/resume_templates/template_1.html` … `template_9.html`: Resume layouts and styling.

Admin templates (`templates/admin/`):
- `_layout.html`: Sidebar layout used by all admin pages.
- `login.html`, `dashboard.html`, `users.html`, `user_view.html`, `resumes.html`, `feedback.html`, `analytics.html`, `templates.html`, `files.html`, `settings.html`, `logs.html`.

Static:
- `static/js/app.js`: Shared behaviors (flash auto-dismiss, OTP boxes, password eye toggle).
- `static/css/style.css`: App styles (including OTP boxes and required-field `*`).

## Database

Default database is SQLite:
- `SQLALCHEMY_DATABASE_URI=sqlite:///users.db`

Key tables (SQLAlchemy models in `app.py`):
- `User`
  - Authentication + profile
  - `saved_resume_data` (JSON string)
  - Resume download tracking: `last_resume_downloaded_at`, `last_resume_download_name`
  - Admin controls: `is_banned`, `banned_at`, `ban_reason`
- `PendingSignup`, `PendingLogin`, `PendingPasswordReset`
  - Stores OTP codes + expiration for email flows
- `Feedback`
  - Stores rating/comment per user email
- `Admin`
  - Separate admin credentials (`password_hash`)
- `AdminSetting`
  - Key/value settings saved from admin UI
- `AdminLog`
  - Simple audit log of admin actions

The app runs `db.create_all()` automatically and also runs a small migration for the `user` table to add missing columns.

## Routes

This is the current route map (run-time):

**User**
- `/` home
- `/register`, `/verify`
- `/login`, `/login/verify`, `/logout`
- `/google-login`, `/auth/callback`
- `/forgot-password`, `/set-password`
- `/account`
- `/resume`, `/resume/save`, `/resume/import`
- `/preview`, `/preview/photo`
- `/export/<file_format>`, `/generate`
- `/feedback`

**Admin**
- `/admin/login`, `/admin/logout`
- `/admin/dashboard`
- `/admin/users`, `/admin/users/<id>` + ban/unban/delete actions
- `/admin/resumes`
- `/admin/feedback` + delete action
- `/admin/analytics`
- `/admin/templates`
- `/admin/files` + download/delete
- `/admin/settings`
- `/admin/logs`

**APIs**
- `/api/ai/*` (AI endpoints)
- `/api/preview/render-template/<template_id>` (template thumbs)
- `/api/preview/save-fields` (inline preview edits → form fields)

## Configuration (.env)

Copy `.env.example` → `.env` and adjust values.

### Environment variables reference

| Variable | Used for | Notes |
|---|---|---|
| `FLASK_SECRET_KEY` | Session signing | Required for production |
| `SQLALCHEMY_DATABASE_URI` | Database connection | Default: `sqlite:///users.db` |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | Google OAuth | Optional |
| `OAUTHLIB_INSECURE_TRANSPORT` | OAuth over HTTP | Local only |
| `SMTP_HOST` / `SMTP_PORT` | Email OTP sending | Required for OTP features |
| `SMTP_USERNAME` / `SMTP_PASSWORD` | SMTP auth | Use app-password when needed |
| `SMTP_SENDER` | From address | Must match provider rules |
| `SMTP_USE_TLS` / `SMTP_USE_SSL` | SMTP security | One of them usually enabled |
| `OPENAI_API_KEY` / `OPENAI_MODEL` | OpenAI provider | Optional model override |
| `GOOGLE_API_KEY` / `GOOGLE_MODEL` | Gemini provider | Optional model override |
| `GROQ_API_KEY` / `GROQ_MODEL` | Groq provider | Optional model override |
| `AI_PROVIDER` | Force provider | `groq` / `openai` / `gemini` |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | First admin creation | Creates Admin row on startup if missing |

### Required (production)
- `FLASK_SECRET_KEY`
- `SQLALCHEMY_DATABASE_URI`

### Google OAuth (optional)
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `OAUTHLIB_INSECURE_TRANSPORT=1` (local only; do not use in production)

### SMTP / Email OTP (required for email login/verification/forgot-password)
- `SMTP_HOST`, `SMTP_PORT`
- `SMTP_USERNAME`, `SMTP_PASSWORD`
- `SMTP_SENDER`
- `SMTP_USE_TLS` and/or `SMTP_USE_SSL`

Notes:
- You can also set `GMAIL_ADDRESS` + `GMAIL_APP_PASSWORD` as shortcuts.
- Admin Settings (`/admin/settings`) can store SMTP values as DB settings; the email sender uses `.env` first, then DB settings as fallback.

### AI provider (choose one)
- OpenAI: `OPENAI_API_KEY`, optional `OPENAI_MODEL`
- Gemini: `GOOGLE_API_KEY`, optional `GOOGLE_MODEL`
- Groq: `GROQ_API_KEY`, optional `GROQ_MODEL`
- Optional: `AI_PROVIDER=groq|openai|gemini` to force selection if multiple keys exist

### Admin (recommended)
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

On startup, if these are set and no admin exists yet, the app creates one automatically.

## Local setup

1. Create a virtual environment (recommended)
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```

2. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```

3. Create `.env`
   ```bash
   copy .env.example .env
   ```

4. Run the app
   ```bash
   python app.py
   ```

Open: `http://127.0.0.1:5000`

### PDF export on Windows (WeasyPrint)
WeasyPrint requires additional native dependencies (GTK). If export fails, install the Windows GTK runtime and retry. The helper in `resumegenerate.py` attempts to locate common GTK install paths.

## Troubleshooting

**1) “No AI API key configured”**
- Set exactly one of: `OPENAI_API_KEY`, `GOOGLE_API_KEY`, or `GROQ_API_KEY`
- Restart the app after editing `.env`

**2) OTP emails not sending**
- Verify SMTP settings in `.env` (or via `/admin/settings`)
- Confirm your email provider allows SMTP/app-password logins

**3) PDF export unavailable**
- Install `weasyprint` (already in `requirements.txt`)
- Install Windows GTK runtime (required by WeasyPrint)

**4) Resume import says PDF parsing not installed**
- Install optional deps:
  ```bash
  pip install pypdf python-docx
  ```

## Security notes

- Do not commit `.env` to Git.
- Change `FLASK_SECRET_KEY` for production.
- Use HTTPS in production (especially for OAuth + sessions).
- Do not use `OAUTHLIB_INSECURE_TRANSPORT=1` in production.
- Admin credentials should be strong; consider rotating `ADMIN_PASSWORD` after first login.
